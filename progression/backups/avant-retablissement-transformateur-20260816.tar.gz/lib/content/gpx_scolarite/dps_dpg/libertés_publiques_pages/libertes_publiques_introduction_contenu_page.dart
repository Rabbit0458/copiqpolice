import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:copiqpolice/content/gpx_scolarite/shared/scolarite_text.dart';

class LibertesPubliquesIntroductionContenuPage extends StatelessWidget {
  const LibertesPubliquesIntroductionContenuPage({super.key});

  static const String routeName =
      '/gpx_scolarite_pages/libertés_publiques_pages/introduction';

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final Color bg = isDark ? const Color(0xFF373737) : const Color(0xFFFFFFFF);
    final Color textMain = isDark ? Colors.white : const Color(0xFF050505);
    final Color textSoft = isDark
        ? Colors.white70
        : const Color(0xFF222222).withValues(alpha: .70);

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          onPressed: () => Navigator.of(context).maybePop(),
          icon: Icon(Icons.arrow_back_ios_new_rounded, color: textMain),
          tooltip: ScolariteText.value(
            "lib/content/gpx_scolarite/dps_dpg/libertés_publiques_pages/libertes_publiques_introduction_contenu_page.dart",
            "f00001",
            'Retour',
          ),
        ),
        title: Text(
          ScolariteText.value(
            "lib/content/gpx_scolarite/dps_dpg/libertés_publiques_pages/libertes_publiques_introduction_contenu_page.dart",
            "f00002",
            "Libertés publiques",
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: GoogleFonts.fustat(
            fontWeight: FontWeight.w900,
            fontSize: 18,
            color: textMain,
          ),
        ),
      ),
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
        children: [
          Text(
            "Introduction",
            style: GoogleFonts.fustat(
              fontWeight: FontWeight.w900,
              fontSize: 21,
              height: 1.15,
              color: textMain,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/libertés_publiques_pages/libertes_publiques_introduction_contenu_page.dart",
                  "f00003",
                  "Accédez aux fiches d’introduction aux libertés publiques : fondements, sources, ",
                ) +
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/libertés_publiques_pages/libertes_publiques_introduction_contenu_page.dart",
                  "f00004",
                  "régime juridique et notions essentielles.",
                ),
            style: GoogleFonts.fustat(
              fontWeight: FontWeight.w500,
              fontSize: 13.5,
              height: 1.35,
              color: textSoft,
            ),
          ),
          const SizedBox(height: 18),

          // ================= 1 =================
          _ModuleCard(
            tag: 'lp_intro_ddhc_1789',
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/libertés_publiques_pages/libertes_publiques_introduction_contenu_page.dart",
              "f00005",
              "La Déclaration des droits de l’homme et du citoyen du 26 août 1789",
            ),
            subtitle: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/libertés_publiques_pages/libertes_publiques_introduction_contenu_page.dart",
              "f00006",
              "Texte fondateur : principes, portée et place dans la hiérarchie des normes.",
            ),
            imagePath: 'assets/images/personnalite.jpeg',
            textMain: textMain,
            textSoft: textSoft,
            onTap: () => _openRoute(
              context,
              '/gpx_scolarite_pages/libertés_publiques_pages/introduction/declaration_droits_homme_citoyen_1789',
            ),
          ),
          const SizedBox(height: 14),

          // ================= 2 =================
          _ModuleCard(
            tag: 'lp_intro_regime_juridique',
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/libertés_publiques_pages/libertes_publiques_introduction_contenu_page.dart",
              "f00007",
              "Le régime juridique : réglementation et aménagement des libertés publiques",
            ),
            subtitle: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/libertés_publiques_pages/libertes_publiques_introduction_contenu_page.dart",
              "f00008",
              "Comment l’État encadre les libertés : conditions, limites, contrôles.",
            ),
            imagePath: 'assets/images/personnalite.jpeg',
            textMain: textMain,
            textSoft: textSoft,
            onTap: () => _openRoute(
              context,
              '/gpx_scolarite_pages/libertés_publiques_pages/introduction/regime_juridique_reglementation_amenagement',
            ),
          ),
          const SizedBox(height: 14),

          // ================= 3 =================
          _ModuleCard(
            tag: 'lp_intro_sources',
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/libertés_publiques_pages/libertes_publiques_introduction_contenu_page.dart",
              "f00009",
              "Les sources des libertés publiques",
            ),
            subtitle: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/libertés_publiques_pages/libertes_publiques_introduction_contenu_page.dart",
              "f00010",
              "Constitution, lois, règlements, jurisprudence et sources internationales.",
            ),
            imagePath: 'assets/images/personnalite.jpeg',
            textMain: textMain,
            textSoft: textSoft,
            onTap: () => _openRoute(
              context,
              '/gpx_scolarite_pages/libertés_publiques_pages/introduction/sources_libertes_publiques',
            ),
          ),
          const SizedBox(height: 14),

          // ================= 4 =================
          _ModuleCard(
            tag: 'lp_intro_notion',
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/libertés_publiques_pages/libertes_publiques_introduction_contenu_page.dart",
              "f00011",
              "Notion de libertés publiques",
            ),
            subtitle: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/libertés_publiques_pages/libertes_publiques_introduction_contenu_page.dart",
              "f00012",
              "Définition, enjeux, distinctions et cadre général.",
            ),
            imagePath: 'assets/images/personnalite.jpeg',
            textMain: textMain,
            textSoft: textSoft,
            onTap: () => _openRoute(
              context,
              '/gpx_scolarite_pages/libertés_publiques_pages/introduction/notion_libertes_publiques',
            ),
          ),

          const SizedBox(height: 22),

          // ================= QUIZ =================
          _ModuleCard(
            tag: 'quiz_lp_introduction',
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/libertés_publiques_pages/libertes_publiques_introduction_contenu_page.dart",
              "f00013",
              'Quiz — Libertés publiques (introduction)',
            ),
            subtitle: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/libertés_publiques_pages/libertes_publiques_introduction_contenu_page.dart",
              "f00014",
              'Testez vos connaissances sur les notions, sources et encadrement des libertés.',
            ),
            imagePath: 'assets/images/quiz.jpeg',
            textMain: textMain,
            textSoft: textSoft,
            onTap: () => _openRoute(
              context,
              '/gpx/libertes_publiques/quiz/introduction',
            ),
          ),

          const SizedBox(height: 22),
        ],
      ),
    );
  }

  void _openRoute(BuildContext context, String routeName) {
    Navigator.of(context).pushNamed(routeName);
  }
}

class _ModuleCard extends StatelessWidget {
  const _ModuleCard({
    required this.tag,
    required this.title,
    required this.subtitle,
    required this.imagePath,
    required this.textMain,
    required this.textSoft,
    required this.onTap,
  });

  final String tag;
  final String title;
  final String subtitle;
  final String imagePath;
  final Color textMain;
  final Color textSoft;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final Color subtitleColor = isDark
        ? textSoft
        : Colors.white.withValues(alpha: 0.92);
    final Color badgeBg = Colors.white.withValues(alpha: 0.14);
    final Color borderClr = Colors.white.withValues(alpha: 0.18);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 200,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: Colors.transparent,
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Hero(
              tag: 'hero_$tag',
              child: Image.asset(
                imagePath,
                fit: BoxFit.cover,
                alignment: Alignment.center,
                filterQuality: FilterQuality.high,
              ),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withValues(alpha: .25),
                    Colors.black.withValues(alpha: .60),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: badgeBg,
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(color: borderClr),
                    ),
                    child: Text(
                      title.toLowerCase().startsWith('quiz') ? 'QUIZ' : 'PDF',
                      style: GoogleFonts.fustat(
                        fontWeight: FontWeight.w800,
                        fontSize: 12,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.fustat(
                      fontWeight: FontWeight.w900,
                      fontSize: 24,
                      height: 1.05,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    subtitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.fustat(
                      fontWeight: FontWeight.w500,
                      fontSize: 13.5,
                      height: 1.3,
                      color: subtitleColor,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
