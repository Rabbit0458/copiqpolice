import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:copiqpolice/content/gpx_scolarite/shared/scolarite_text.dart';

class DefautPermisPage extends StatelessWidget {
  const DefautPermisPage({super.key});

  static const String routeName =
      '/gpx_scolarite_pages/infraction_circulation_routière_pages/defaut_permis';

  static const Color _lawRed = Color(0xFFE53935);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final Color bg = isDark ? const Color(0xFF373737) : const Color(0xFFFFFFFF);
    final Color textMain = isDark ? Colors.white : const Color(0xFF050505);

    // Palette cards (propre + lisible)
    final Color cardDef = isDark
        ? const Color(0xFF222224)
        : const Color(0xFFF7F7F7);
    final Color cardLegal = isDark
        ? const Color(0xFF1F2733)
        : const Color(0xFFF2F6FF);
    final Color cardMat = isDark
        ? const Color(0xFF1D2A24)
        : const Color(0xFFF1FBF5);
    final Color cardMoral = isDark
        ? const Color(0xFF2A1F2D)
        : const Color(0xFFFFF1F8);
    final Color cardAggr = isDark
        ? const Color(0xFF2C2417)
        : const Color(0xFFFFF8E1);
    final Color cardRep = isDark
        ? const Color(0xFF222224)
        : const Color(0xFFF7F7F7);
    final Color cardConst = isDark
        ? const Color(0xFF1E1E1E)
        : const Color(0xFFF2F2F2);

    final Color accentBlue = isDark
        ? const Color(0xFF64B5F6)
        : const Color(0xFF1565C0);
    final Color accentGreen = isDark
        ? const Color(0xFF66BB6A)
        : const Color(0xFF2E7D32);
    final Color accentPink = isDark
        ? const Color(0xFFF48FB1)
        : const Color(0xFFC2185B);
    final Color accentAmber = isDark
        ? const Color(0xFFFFCA28)
        : const Color(0xFFF9A825);
    final Color accentGrey = isDark ? Colors.white70 : const Color(0xFF616161);

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          onPressed: () => Navigator.of(context).maybePop(),
          icon: Icon(Icons.arrow_back_ios_new_rounded, color: textMain),
          tooltip: ScolariteText.value(
            "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
            "f00001",
            'Retour',
          ),
        ),
        title: Text(
          ScolariteText.value(
            "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
            "f00002",
            "Infraction circulation routière",
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: GoogleFonts.fustat(
            fontWeight: FontWeight.w900,
            fontSize: 18,
            color: textMain,
          ),
        ),
      ),
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
        children: [
          Text(
            ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
              "f00003",
              "Le défaut de permis de conduire",
            ),
            style: GoogleFonts.fustat(
              fontWeight: FontWeight.w900,
              fontSize: 21,
              height: 1.15,
              color: textMain,
            ),
          ),
          const SizedBox(height: 10),

          // Définition
          _ConditionCard(
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
              "f00004",
              "Définition",
            ),
            cardColor: cardDef,
            accent: accentGrey,
            titleColor: textMain,
            children: [
              _Paragraph(
                ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                      "f00005",
                      "Le fait de conduire un véhicule sans être titulaire du permis de conduire correspondant ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                      "f00006",
                      "à la catégorie du véhicule considéré constitue une infraction.",
                    ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // ✅ Élément légal en haut
          _ConditionCard(
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
              "f00007",
              "I — Élément légal",
            ),
            cardColor: cardLegal,
            accent: accentBlue,
            titleColor: textMain,
            children: [
              _Paragraph.rich([
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00008",
                    "Article L. 221-2 / I du Code de la route",
                  ),
                  style: TextStyle(color: _lawRed, fontWeight: FontWeight.w900),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00009",
                    " : définit et réprime le défaut de permis de conduire.",
                  ),
                ),
              ]),
            ],
          ),

          const SizedBox(height: 14),

          // Élément matériel
          _ConditionCard(
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
              "f00010",
              "II — Élément matériel",
            ),
            cardColor: cardMat,
            accent: accentGreen,
            titleColor: textMain,
            children: [
              _SubTitle(
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00011",
                  "A) Un conducteur de véhicule",
                ),
              ),
              _Paragraph.rich([
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00012",
                    "Article R. 221-1-1 / I du Code de la route",
                  ),
                  style: TextStyle(color: _lawRed, fontWeight: FontWeight.w900),
                ),
                TextSpan(
                  text:
                      ScolariteText.value(
                        "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                        "f00013",
                        " : « nul ne peut conduire un véhicule (ou un ensemble) pour lequel le permis est exigé s’il ",
                      ) +
                      ScolariteText.value(
                        "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                        "f00014",
                        "n’est titulaire de la catégorie correspondante du permis en état de validité et s’il ne respecte ",
                      ) +
                      ScolariteText.value(
                        "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                        "f00015",
                        "les restrictions d’usage mentionnées sur ce titre ».",
                      ),
                ),
              ]),

              SizedBox(height: 14),

              _SubTitle(
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00016",
                  "B) Un défaut de permis de conduire (au sens strict)",
                ),
              ),
              _Paragraph(
                ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                      "f00017",
                      "Les règles relatives au permis de conduire sont précisées notamment par :\n",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                      "f00018",
                      "• les articles R. 221-1-1 à R. 221-21 du Code de la route (délivrance) ;\n",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                      "f00019",
                      "• et les articles R. 222-1 à R. 222-8 du Code de la route (reconnaissances et équivalences).",
                    ),
              ),
              SizedBox(height: 10),
              _Paragraph.rich([
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00020",
                    "Article L. 221-1 du Code de la route",
                  ),
                  style: TextStyle(color: _lawRed, fontWeight: FontWeight.w900),
                ),
                TextSpan(
                  text:
                      ScolariteText.value(
                        "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                        "f00021",
                        " : précise que sont assimilés au permis de conduire certains titres prévus par les règlements ",
                      ) +
                      ScolariteText.value(
                        "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                        "f00022",
                        "pour la conduite des véhicules à moteur, lorsque le permis n’est pas exigé.",
                      ),
                ),
              ]),
              SizedBox(height: 10),
              _NotaBox(
                title: "Important",
                bodySpans: [
                  TextSpan(
                    text:
                        ScolariteText.value(
                          "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                          "f00023",
                          "Le brevet de sécurité routière (BSR) n’entre pas dans le champ de l’infraction définie pour le défaut de permis ",
                        ) +
                        ScolariteText.value(
                          "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                          "f00024",
                          "au sens de l’article ",
                        ),
                  ),
                  TextSpan(
                    text: ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                      "f00025",
                      "L. 221-2 / I du Code de la route",
                    ),
                    style: TextStyle(
                      color: _lawRed,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  TextSpan(text: "."),
                ],
              ),

              SizedBox(height: 14),

              _SubTitle(
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00026",
                  "C) À ne pas confondre",
                ),
              ),
              _BulletPoint(
                text: ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00027",
                  "Non-présentation du permis : ce n’est pas le défaut de permis, mais une contravention distincte.",
                ),
              ),
              _Paragraph.rich([
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00028",
                    "→ Non-présentation : ",
                  ),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00029",
                    "article R. 233-1 du Code de la route",
                  ),
                  style: TextStyle(color: _lawRed, fontWeight: FontWeight.w900),
                ),
                TextSpan(text: "."),
              ]),
              SizedBox(height: 10),
              _BulletPoint(
                text: ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00030",
                  "Conduite malgré suspension / rétention / annulation / interdiction d’obtenir un permis : infraction différente.",
                ),
              ),
              _Paragraph.rich([
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00031",
                    "→ Conduite malgré mesure : ",
                  ),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00032",
                    "article L. 224-16 du Code de la route",
                  ),
                  style: TextStyle(color: _lawRed, fontWeight: FontWeight.w900),
                ),
                TextSpan(text: "."),
              ]),
              SizedBox(height: 10),
              _NotaBox(
                title: "Nota",
                bodySpans: [
                  TextSpan(
                    text: ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                      "f00033",
                      "L’article L. 221-2 / I du Code de la route prévoit une liste d’exceptions.",
                    ),
                  ),
                ],
              ),
            ],
          ),

          const SizedBox(height: 14),

          // Élément moral
          _ConditionCard(
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
              "f00034",
              "III — Élément moral",
            ),
            cardColor: cardMoral,
            accent: accentPink,
            titleColor: textMain,
            children: [
              _SubTitle(
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00035",
                  "Conduite volontaire sans être titulaire du permis requis",
                ),
              ),
              _Paragraph(
                ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                      "f00036",
                      "L’infraction est intentionnelle : elle suppose la volonté de conduire un véhicule ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                      "f00037",
                      "sans être titulaire du permis correspondant à la catégorie du véhicule concerné.",
                    ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // Circonstances aggravantes
          _ConditionCard(
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
              "f00038",
              "IV — Circonstances aggravantes",
            ),
            cardColor: cardAggr,
            accent: accentAmber,
            titleColor: textMain,
            children: [
              _Paragraph.rich([
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00039",
                    "Article L. 221-2-1 du Code de la route",
                  ),
                  style: TextStyle(color: _lawRed, fontWeight: FontWeight.w900),
                ),
                TextSpan(text: " :"),
              ]),
              SizedBox(height: 8),
              _BulletPoint(
                text: ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00040",
                  "Défaut de permis de conduire avec usage d’un permis faux ou falsifié.",
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // Répression + tentative/complicité
          _ConditionCard(
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
              "f00041",
              "V — Répression",
            ),
            cardColor: cardRep,
            accent: accentGrey,
            titleColor: textMain,
            children: [
              _SubTitle(
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00042",
                  "Peines encourues",
                ),
              ),
              _Paragraph.rich([
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00043",
                    "Simple : ",
                  ),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00044",
                    "1 an d’emprisonnement et 15 000 € d’amende. — ",
                  ),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00045",
                    "article L. 221-2 / I du Code de la route",
                  ),
                  style: TextStyle(color: _lawRed, fontWeight: FontWeight.w900),
                ),
              ]),
              SizedBox(height: 8),
              _Paragraph.rich([
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00046",
                    "Aggravée (permis faux/falsifié) : ",
                  ),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00047",
                    "5 ans d’emprisonnement et 75 000 € d’amende. — ",
                  ),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00048",
                    "article L. 221-2-1 / I du Code de la route",
                  ),
                  style: TextStyle(color: _lawRed, fontWeight: FontWeight.w900),
                ),
              ]),

              SizedBox(height: 12),

              _SubTitle(
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00049",
                  "Tentative & complicité",
                ),
              ),
              _BulletPoint(
                text: ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00050",
                  "Tentative : NON.",
                ),
              ),
              _BulletPoint(
                text: ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00051",
                  "Complicité : OUI.",
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // Constatation (AFD)
          _ConditionCard(
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
              "f00052",
              "VI — Constatation de l’infraction",
            ),
            cardColor: cardConst,
            accent: accentGrey,
            titleColor: textMain,
            children: [
              _Paragraph.rich([
                TextSpan(
                  text:
                      ScolariteText.value(
                        "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                        "f00053",
                        "L’action publique peut être éteinte par le paiement d’une amende forfaitaire délictuelle ",
                      ) +
                      ScolariteText.value(
                        "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                        "f00054",
                        "fixée par la loi dans les conditions prévues à ",
                      ),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00055",
                    "l’article D. 45-3 du Code de procédure pénale",
                  ),
                  style: TextStyle(color: _lawRed, fontWeight: FontWeight.w900),
                ),
                TextSpan(text: "."),
              ]),
              SizedBox(height: 10),
              _SubTitle(
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00056",
                  "Champ d’application",
                ),
              ),
              _BulletPoint(
                text: ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00057",
                  "Conduite d’un véhicule sans permis.",
                ),
              ),
              _BulletPoint(
                text: ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00058",
                  "Conduite avec un permis n’autorisant pas la conduite du véhicule concerné.",
                ),
              ),

              SizedBox(height: 10),

              _SubTitle(
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00059",
                  "Condition pratique",
                ),
              ),
              _Paragraph(
                ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                      "f00060",
                      "L’infraction doit être constatée par procès-verbal électronique (PVe) dressé au moyen d’un appareil sécurisé ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                      "f00061",
                      "(terminaux Néo).\n",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                      "f00062",
                      "Cette procédure doit être limitée aux cas ne laissant aucun doute sur la caractérisation de l’infraction ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                      "f00063",
                      "et ne nécessitant pas d’investigations complémentaires.",
                    ),
              ),

              SizedBox(height: 12),

              _Paragraph.rich([
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00064",
                    "La procédure AFD n’est pas applicable (",
                  ),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                    "f00065",
                    "article 495-17 du Code de procédure pénale",
                  ),
                  style: TextStyle(color: _lawRed, fontWeight: FontWeight.w900),
                ),
                TextSpan(text: ") :"),
              ]),
              SizedBox(height: 8),
              _BulletPoint(
                text: ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00066",
                  "Si le délit a été commis par un mineur.",
                ),
              ),
              _BulletPoint(
                text: ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00067",
                  "Si le délit a été commis en état de récidive légale (mention TAJ pour le même délit ou un délit assimilé), sauf disposition contraire.",
                ),
              ),
              _BulletPoint(
                text: ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/infraction_circulation_routière_pages/defaut_permis_contenu_page.dart",
                  "f00068",
                  "Si plusieurs infractions sont constatées simultanément et qu’au moins l’une ne peut donner lieu à une amende forfaitaire.",
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

///////////////////////////////////////////////////////////////////////////////
///                   TES WIDGETS PERSONNALISÉS EXACTS                    ///
///////////////////////////////////////////////////////////////////////////////

class _ConditionCard extends StatelessWidget {
  const _ConditionCard({
    required this.title,
    required this.cardColor,
    required this.accent,
    required this.titleColor,
    required this.children,
  });

  final String title;
  final Color cardColor;
  final Color accent;
  final Color titleColor;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      container: true,
      header: true,
      child: Container(
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: accent.withValues(alpha: .22), width: 0.8),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: .12),
              blurRadius: 18,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: GoogleFonts.fustat(
                fontWeight: FontWeight.w800,
                fontSize: 16.5,
                color: titleColor,
              ),
            ),
            const SizedBox(height: 12),
            ...children,
          ],
        ),
      ),
    );
  }
}

class _SubTitle extends StatelessWidget {
  const _SubTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.only(top: 6, bottom: 6),
      child: Text(
        text,
        style: GoogleFonts.fustat(
          fontWeight: FontWeight.w700,
          fontSize: 15.5,
          color: isDark ? Colors.white : const Color(0xFF0D47A1),
        ),
      ),
    );
  }
}

class _Paragraph extends StatelessWidget {
  const _Paragraph(this.text) : spans = null;

  const _Paragraph.rich(this.spans) : text = null;

  final String? text;
  final List<TextSpan>? spans;

  @override
  Widget build(BuildContext context) {
    final isRich = spans != null;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final Color color = isDark
        ? Colors.white70
        : const Color(0xFF1F1F1F).withValues(alpha: .92);

    if (!isRich) {
      return Text(
        text!,
        textAlign: TextAlign.justify,
        style: GoogleFonts.fustat(
          fontSize: 14,
          height: 1.45,
          fontWeight: FontWeight.w500,
          color: color,
        ),
      );
    }

    return RichText(
      textAlign: TextAlign.justify,
      text: TextSpan(
        style: GoogleFonts.fustat(
          fontSize: 14,
          height: 1.45,
          fontWeight: FontWeight.w500,
          color: color,
        ),
        children: spans!,
      ),
    );
  }
}

class _IntroBullet extends StatelessWidget {
  const _IntroBullet({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final Color bulletColor = isDark
        ? const Color(0xFF64B5F6)
        : const Color(0xFF1565C0);
    final Color textColor = isDark
        ? Colors.white70
        : const Color(0xFF1F1F1F).withValues(alpha: .92);

    return Padding(
      padding: const EdgeInsets.only(bottom: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Icon(
              Icons.arrow_right_rounded,
              size: 18,
              color: bulletColor,
            ),
          ),
          const SizedBox(width: 2),
          Expanded(
            child: Text(
              text,
              style: GoogleFonts.fustat(
                fontSize: 14,
                height: 1.3,
                fontWeight: FontWeight.w500,
                color: textColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _BulletPoint extends StatelessWidget {
  const _BulletPoint({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.check_rounded,
            size: 18,
            color: isDark ? const Color(0xFF64B5F6) : const Color(0xFF1565C0),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              text,
              style: GoogleFonts.fustat(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                height: 1.35,
                color: isDark
                    ? Colors.white70
                    : const Color(0xFF1F1F1F).withValues(alpha: .92),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _NotaBox extends StatelessWidget {
  const _NotaBox({required this.bodySpans, this.title = 'NOTA'});

  final List<TextSpan> bodySpans;
  final String title;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final Color borderColor = isDark
        ? const Color(0xFFFFCA28)
        : const Color(0xFFF9A825);
    final Color bgColor = isDark
        ? const Color(0xFF26200F)
        : const Color(0xFFFFF8E1);
    final Color titleColor = isDark ? Colors.white : const Color(0xFF5D4037);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: bgColor.withValues(alpha: isDark ? .7 : .95),
        borderRadius: BorderRadius.circular(12),
        border: Border(left: BorderSide(color: borderColor, width: 3)),
      ),
      child: RichText(
        textAlign: TextAlign.justify,
        text: TextSpan(
          style: GoogleFonts.fustat(
            fontSize: 13.5,
            fontWeight: FontWeight.w500,
            height: 1.4,
            color: isDark
                ? Colors.white70
                : const Color(0xFF3E2723).withValues(alpha: .95),
          ),
          children: [
            TextSpan(
              text: '$title : ',
              style: TextStyle(fontWeight: FontWeight.w900, color: titleColor),
            ),
            ...bodySpans,
          ],
        ),
      ),
    );
  }
}
