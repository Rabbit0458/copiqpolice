import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:copiqpolice/content/gpx_scolarite/shared/scolarite_text.dart';

class DetentionTransportSubstancesPreparationPage extends StatelessWidget {
  const DetentionTransportSubstancesPreparationPage({super.key});

  static const String routeName =
      '/gpx_scolarite_pages/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation';

  static const Color _lawRed = Color(0xFFE53935);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final Color bg = isDark ? const Color(0xFF373737) : const Color(0xFFFFFFFF);
    final Color textMain = isDark ? Colors.white : const Color(0xFF050505);

    // Palette cards (propre + lisible)
    final Color cardLegal = isDark
        ? const Color(0xFF1F2733)
        : const Color(0xFFF2F6FF);
    final Color cardMat = isDark
        ? const Color(0xFF1D2A24)
        : const Color(0xFFF1FBF5);
    final Color cardMoral = isDark
        ? const Color(0xFF2A1F2D)
        : const Color(0xFFFFF1F8);
    final Color cardAggr = isDark
        ? const Color(0xFF2C2417)
        : const Color(0xFFFFF8E1);
    final Color cardRep = isDark
        ? const Color(0xFF222224)
        : const Color(0xFFF7F7F7);

    final Color accentBlue = isDark
        ? const Color(0xFF64B5F6)
        : const Color(0xFF1565C0);
    final Color accentGreen = isDark
        ? const Color(0xFF66BB6A)
        : const Color(0xFF2E7D32);
    final Color accentPink = isDark
        ? const Color(0xFFF48FB1)
        : const Color(0xFFC2185B);
    final Color accentAmber = isDark
        ? const Color(0xFFFFCA28)
        : const Color(0xFFF9A825);
    final Color accentGrey = isDark ? Colors.white70 : const Color(0xFF616161);

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          onPressed: () => Navigator.of(context).maybePop(),
          icon: Icon(Icons.arrow_back_ios_new_rounded, color: textMain),
          tooltip: ScolariteText.value(
            "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
            "f00001",
            'Retour',
          ),
        ),
        title: Text(
          ScolariteText.value(
            "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
            "f00002",
            "Destructions, dégradations",
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: GoogleFonts.fustat(
            fontWeight: FontWeight.w900,
            fontSize: 18,
            color: textMain,
          ),
        ),
      ),
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
        children: [
          Text(
            ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
              "f00003",
              "La détention ou le transport de substances ou produits incendiaires ou explosifs en vue de la préparation de destruction, dégradation ou détérioration dangereuses ou d’une atteinte aux personnes",
            ),
            style: GoogleFonts.fustat(
              fontWeight: FontWeight.w900,
              fontSize: 20.5,
              height: 1.15,
              color: textMain,
            ),
          ),
          const SizedBox(height: 10),

          // Définition
          _ConditionCard(
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
              "f00004",
              "Définition",
            ),
            cardColor: cardRep,
            accent: accentGrey,
            titleColor: textMain,
            children: [
              _Paragraph(
                ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00005",
                      "La détention ou le transport de substances ou produits incendiaires ou explosifs ainsi que d’éléments ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00006",
                      "ou substances destinés à entrer dans la composition de produits ou engins incendiaires ou explosifs ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00007",
                      "en vue de la préparation, caractérisée par un ou plusieurs faits matériels, des infractions définies ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00008",
                      "à l’article 322-6 du Code pénal ou d’atteintes aux personnes, constitue une infraction.",
                    ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // ✅ Élément légal en haut
          _ConditionCard(
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
              "f00009",
              "I — Élément légal",
            ),
            cardColor: cardLegal,
            accent: accentBlue,
            titleColor: textMain,
            children: [
              _Paragraph.rich([
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                    "f00010",
                    "Article 322-11-1 alinéa 1 du Code pénal",
                  ),
                  style: TextStyle(color: _lawRed, fontWeight: FontWeight.w900),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                    "f00011",
                    " : définit et réprime la détention ou le transport de substances ou produits incendiaires ou explosifs en vue de la préparation d’infractions dangereuses.",
                  ),
                ),
              ]),
            ],
          ),

          const SizedBox(height: 14),

          // Élément matériel
          _ConditionCard(
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
              "f00012",
              "II — Élément matériel",
            ),
            cardColor: cardMat,
            accent: accentGreen,
            titleColor: textMain,
            children: [
              _Paragraph(
                ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00013",
                      "Les violences urbaines sont souvent marquées par des incendies (bâtiments, véhicules), provoqués ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00014",
                      "notamment par des engins explosifs ou incendiaires improvisés (jets d’essence, cocktails Molotov). ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00015",
                      "Pour prévenir ces phénomènes, le législateur a créé une infraction spécifique permettant de réprimer ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00016",
                      "certains comportements avant que les destructions ne soient commises ou tentées.",
                    ),
              ),
              SizedBox(height: 12),

              _SubTitle(
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                  "f00017",
                  "A) La détention ou le transport",
                ),
              ),
              _Paragraph(
                ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00018",
                      "L’auteur est trouvé en possession de substances ou produits soit incendiaires, soit explosifs. ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00019",
                      "Cette possession peut prendre deux formes : la détention ou le transport.",
                    ),
              ),
              SizedBox(height: 10),
              _BulletPoint(
                text: ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                  "f00020",
                  "Détention : avoir à sa disposition ces substances ou produits, sans être nécessairement possesseur ou propriétaire.",
                ),
              ),
              _BulletPoint(
                text: ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                  "f00021",
                  "Transport : déplacer ces substances ou produits, notamment sur la voie publique.",
                ),
              ),
              SizedBox(height: 10),
              _Paragraph(
                ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00022",
                      "Les incriminations de détention et de transport offrent une grande souplesse : être trouvé porteur ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00023",
                      "de tels produits sur la voie publique peut caractériser à la fois la détention et le transport.",
                    ),
              ),

              SizedBox(height: 14),

              _SubTitle(
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                  "f00024",
                  "B) La nature des substances / produits",
                ),
              ),
              _Paragraph(
                ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00025",
                      "Sont visés :\n",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00026",
                      "• les poudres et substances explosives, ainsi que les produits ouvrés comportant des substances explosives (ex. dynamite)\n",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00027",
                      "• les explosifs artisanaux (engins explosifs improvisés)\n",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00028",
                      "• les produits incendiaires (ex. cocktails Molotov).",
                    ),
              ),
              SizedBox(height: 10),
              _SubTitle(
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                  "f00029",
                  "C) Les éléments destinés à entrer dans la composition d’engins",
                ),
              ),
              _Paragraph(
                ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00030",
                      "De nombreux éléments peuvent être concernés (liste non exhaustive) : mèche lente, détonateur, ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00031",
                      "poudre explosive, bouteille de gaz, etc.",
                    ),
              ),
              SizedBox(height: 12),

              _NotaBox(
                bodySpans: [
                  TextSpan(
                    text:
                        ScolariteText.value(
                          "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                          "f00032",
                          "Pluralité exigée : le texte vise des substances, produits ou éléments au pluriel. ",
                        ) +
                        ScolariteText.value(
                          "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                          "f00033",
                          "La jurisprudence retient qu’un seul objet n’est pas suffisant.",
                        ),
                  ),
                ],
              ),

              SizedBox(height: 12),

              _NotaBox(
                bodySpans: [
                  TextSpan(
                    text: ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00034",
                      "Jurisprudence : ",
                    ),
                  ),
                  TextSpan(
                    text: ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00035",
                      "Cass. crim., n° 23-84.092, 20 mars 2024",
                    ),
                    style: TextStyle(
                      color: _lawRed,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  TextSpan(
                    text:
                        ScolariteText.value(
                          "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                          "f00036",
                          " : dès lors que les objets étaient au moins au nombre de deux, mis en œuvre par le feu, ",
                        ) +
                        ScolariteText.value(
                          "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                          "f00037",
                          "leur transport/détention s’inscrivait dans la préparation d’infractions aux personnes ou aux biens.",
                        ),
                  ),
                ],
              ),

              SizedBox(height: 14),

              _SubTitle(
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                  "f00038",
                  "D) La préparation caractérisée d’infractions déterminées",
                ),
              ),
              _Paragraph(
                ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00039",
                      "L’auteur ne doit pas être passé à l’acte, mais sa volonté doit être caractérisée par un ou plusieurs ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00040",
                      "faits matériels. La résolution d’agir est démontrée à partir d’actes préparatoires (ex. transport d’un bidon ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00041",
                      "d’essence + bouteilles vides + chiffons usagés permettant la confection de cocktails Molotov).",
                    ),
              ),
              SizedBox(height: 10),
              _BulletPoint(
                text: ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                  "f00042",
                  "Préparation d’une destruction dangereuse pour les personnes : infraction visée à l’article 322-6 du Code pénal (incendie, substance explosive, etc.).",
                ),
              ),
              _BulletPoint(
                text: ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                  "f00043",
                  "Préparation d’atteintes aux personnes : infractions du titre II du livre II du Code pénal (atteintes à la vie, violences…).",
                ),
              ),

              SizedBox(height: 14),

              _SubTitle(
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                  "f00044",
                  "E) L’absence d’utilisation des substances ou produits",
                ),
              ),
              _Paragraph(
                ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00045",
                      "L’article 322-11-1 alinéa 1 vise à réprimer la détention ou le transport avant toute utilisation. ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00046",
                      "Si l’auteur utilise ou tente d’utiliser les substances/produits, il sera poursuivi sur le fondement ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00047",
                      "de l’article 322-6 du Code pénal (ou d’une infraction d’atteintes aux personnes), et non sur 322-11-1.",
                    ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // Élément moral
          _ConditionCard(
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
              "f00048",
              "III — Élément moral",
            ),
            cardColor: cardMoral,
            accent: accentPink,
            titleColor: textMain,
            children: [
              _Paragraph(
                ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00049",
                      "Le délit ne peut être retenu que si l’intention coupable est démontrée : l’auteur doit avoir ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00050",
                      "conscience de détenir ou de transporter ces substances ou produits dans le but de commettre ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00051",
                      "une infraction dangereuse pour les personnes. La découverte d’actes préparatoires met en évidence ",
                    ) +
                    ScolariteText.value(
                      "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                      "f00052",
                      "son intention malveillante.",
                    ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // Circonstances aggravantes
          _ConditionCard(
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
              "f00053",
              "IV — Circonstances aggravantes",
            ),
            cardColor: cardAggr,
            accent: accentAmber,
            titleColor: textMain,
            children: [
              _Paragraph.rich([
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                    "f00054",
                    "Article 322-11-1 alinéa 2 du Code pénal",
                  ),
                  style: TextStyle(color: _lawRed, fontWeight: FontWeight.w900),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                    "f00055",
                    " : lorsque les faits sont commis en bande organisée.",
                  ),
                ),
              ]),
            ],
          ),

          const SizedBox(height: 14),

          // Répression + tentative/complicité
          _ConditionCard(
            title: ScolariteText.value(
              "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
              "f00056",
              "V — Répression",
            ),
            cardColor: cardRep,
            accent: accentGrey,
            titleColor: textMain,
            children: [
              _SubTitle(
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                  "f00057",
                  "Peines encourues — personnes physiques",
                ),
              ),
              _Paragraph.rich([
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                    "f00058",
                    "Qualification simple : ",
                  ),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                    "f00059",
                    "7 ans d’emprisonnement et 100 000 € d’amende. — ",
                  ),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                    "f00060",
                    "article 322-11-1 alinéa 1 du Code pénal",
                  ),
                  style: TextStyle(color: _lawRed, fontWeight: FontWeight.w900),
                ),
              ]),
              SizedBox(height: 8),
              _Paragraph.rich([
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                    "f00061",
                    "Aggravée (bande organisée) : ",
                  ),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                    "f00062",
                    "10 ans d’emprisonnement et 500 000 € d’amende. — ",
                  ),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                    "f00063",
                    "article 322-11-1 alinéa 2 du Code pénal",
                  ),
                  style: TextStyle(color: _lawRed, fontWeight: FontWeight.w900),
                ),
              ]),

              SizedBox(height: 12),

              _SubTitle(
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                  "f00064",
                  "Personnes morales",
                ),
              ),
              _Paragraph.rich([
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                    "f00065",
                    "Peines prévues par ",
                  ),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                    "f00066",
                    "l’article 322-17 du Code pénal",
                  ),
                  style: TextStyle(color: _lawRed, fontWeight: FontWeight.w900),
                ),
                TextSpan(text: "."),
              ]),

              SizedBox(height: 12),

              _SubTitle(
                ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                  "f00067",
                  "Tentative & complicité",
                ),
              ),
              _BulletPoint(
                text: ScolariteText.value(
                  "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                  "f00068",
                  "Tentative : NON (non punissable).",
                ),
              ),
              _Paragraph.rich([
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                    "f00069",
                    "Complicité : OUI (droit commun). ",
                  ),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                    "f00070",
                    "Article 121-7 du Code pénal",
                  ),
                  style: TextStyle(color: _lawRed, fontWeight: FontWeight.w900),
                ),
                TextSpan(
                  text: ScolariteText.value(
                    "lib/content/gpx_scolarite/dps_dpg/crime_delit_bien_pages/destructions_degradations/detention_transport_substances_preparation_contenu_page.dart",
                    "f00071",
                    " : suppose aide/assistance, provocation ou instructions, et l’intention de s’associer à l’action.",
                  ),
                ),
              ]),
            ],
          ),
        ],
      ),
    );
  }
}

///////////////////////////////////////////////////////////////////////////////
///                   TES WIDGETS PERSONNALISÉS EXACTS                    ///
///////////////////////////////////////////////////////////////////////////////

class _ConditionCard extends StatelessWidget {
  const _ConditionCard({
    required this.title,
    required this.cardColor,
    required this.accent,
    required this.titleColor,
    required this.children,
  });

  final String title;
  final Color cardColor;
  final Color accent;
  final Color titleColor;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      container: true,
      header: true,
      child: Container(
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: accent.withValues(alpha: .22), width: 0.8),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: .12),
              blurRadius: 18,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: GoogleFonts.fustat(
                fontWeight: FontWeight.w800,
                fontSize: 16.5,
                color: titleColor,
              ),
            ),
            const SizedBox(height: 12),
            ...children,
          ],
        ),
      ),
    );
  }
}

class _SubTitle extends StatelessWidget {
  const _SubTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.only(top: 6, bottom: 6),
      child: Text(
        text,
        style: GoogleFonts.fustat(
          fontWeight: FontWeight.w700,
          fontSize: 15.5,
          color: isDark ? Colors.white : const Color(0xFF0D47A1),
        ),
      ),
    );
  }
}

class _Paragraph extends StatelessWidget {
  const _Paragraph(this.text) : spans = null;

  const _Paragraph.rich(this.spans) : text = null;

  final String? text;
  final List<TextSpan>? spans;

  @override
  Widget build(BuildContext context) {
    final isRich = spans != null;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final Color color = isDark
        ? Colors.white70
        : const Color(0xFF1F1F1F).withValues(alpha: .92);

    if (!isRich) {
      return Text(
        text!,
        textAlign: TextAlign.justify,
        style: GoogleFonts.fustat(
          fontSize: 14,
          height: 1.45,
          fontWeight: FontWeight.w500,
          color: color,
        ),
      );
    }

    return RichText(
      textAlign: TextAlign.justify,
      text: TextSpan(
        style: GoogleFonts.fustat(
          fontSize: 14,
          height: 1.45,
          fontWeight: FontWeight.w500,
          color: color,
        ),
        children: spans!,
      ),
    );
  }
}

class _IntroBullet extends StatelessWidget {
  const _IntroBullet({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final Color bulletColor = isDark
        ? const Color(0xFF64B5F6)
        : const Color(0xFF1565C0);
    final Color textColor = isDark
        ? Colors.white70
        : const Color(0xFF1F1F1F).withValues(alpha: .92);

    return Padding(
      padding: const EdgeInsets.only(bottom: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Icon(
              Icons.arrow_right_rounded,
              size: 18,
              color: bulletColor,
            ),
          ),
          const SizedBox(width: 2),
          Expanded(
            child: Text(
              text,
              style: GoogleFonts.fustat(
                fontSize: 14,
                height: 1.3,
                fontWeight: FontWeight.w500,
                color: textColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _BulletPoint extends StatelessWidget {
  const _BulletPoint({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.check_rounded,
            size: 18,
            color: isDark ? const Color(0xFF64B5F6) : const Color(0xFF1565C0),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              text,
              style: GoogleFonts.fustat(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                height: 1.35,
                color: isDark
                    ? Colors.white70
                    : const Color(0xFF1F1F1F).withValues(alpha: .92),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _NotaBox extends StatelessWidget {
  const _NotaBox({required this.bodySpans});

  final List<TextSpan> bodySpans;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final Color borderColor = isDark
        ? const Color(0xFFFFCA28)
        : const Color(0xFFF9A825);
    final Color bgColor = isDark
        ? const Color(0xFF26200F)
        : const Color(0xFFFFF8E1);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: bgColor.withValues(alpha: isDark ? .7 : .95),
        borderRadius: BorderRadius.circular(12),
        border: Border(left: BorderSide(color: borderColor, width: 3)),
      ),
      child: RichText(
        textAlign: TextAlign.justify,
        text: TextSpan(
          style: GoogleFonts.fustat(
            fontSize: 13.5,
            fontWeight: FontWeight.w500,
            height: 1.4,
            color: isDark
                ? Colors.white70
                : const Color(0xFF3E2723).withValues(alpha: .95),
          ),
          children: [...bodySpans],
        ),
      ),
    );
  }
}
