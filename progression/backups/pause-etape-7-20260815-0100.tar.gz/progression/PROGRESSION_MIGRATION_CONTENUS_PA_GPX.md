# Progression — Migration complète des contenus PA/GPX

Dernière mise à jour automatique : `2026-08-14T17:01:19.850765`

## Objectif

Rendre administrables depuis `copiq.fr/admin` tous les cours de PA Scolarité et GPX Scolarité, ainsi que leurs quiz et les quiz PA/GPX Exam, sans modifier l’identité visuelle existante et sans supprimer de table Supabase.

## Périmètre mesuré

- **1409 fichiers Dart** suivis dans le registre exhaustif.
- **759 fichiers GPX Scolarité**.
- **650 fichiers PA Scolarité**.
- Registre détaillé : [AUDIT_MIGRATION_1409_FICHIERS_SCOLARITE.md](./AUDIT_MIGRATION_1409_FICHIERS_SCOLARITE.md)
- Audit structurel fichier par fichier : [AUDIT_DETAILLE_1409_FICHIERS_SCOLARITE.md](./AUDIT_DETAILLE_1409_FICHIERS_SCOLARITE.md)

## Sauvegarde de référence

- Archive : `/private/tmp/copiqpolice-before-content-migration-20260814-161850.tar.gz`
- Taille : **2,8 Go**
- SHA-256 : `cdae106a848bb0f894c76fcdb0981c9a2f0244a89c63b1787896fa1ce9d19e15`

## Décisions validées

- [x] Lire tous les fichiers Dart de `gpx_scolarite` et `pa_scolarite`.
- [x] Migrer l’intégralité du contenu éditorial, pas uniquement les paragraphes simples.
- [x] Conserver les designs, routes et moteurs Flutter existants.
- [x] Permettre la création de nouveaux cours sans republication sur les stores.
- [x] Conserver le design actuel du panneau administrateur.
- [x] Fournir un éditeur visuel par blocs et un mode Markdown avancé synchronisé.
- [x] Gérer images, PDF, vidéos, audio et schémas via Supabase Storage.
- [x] Appliquer les migrations Supabase après sauvegarde et contrôle RLS.
- [x] Ne supprimer aucune table Supabase existante.

## État actuel

| Lot | État | Détail |
|---|---|---|
| Sauvegarde initiale | Terminé | Archive complète et SHA-256 vérifiés |
| Audit Supabase distant | Terminé | Projet, tables, RLS, politiques, fonctions, Storage et conseillers contrôlés en lecture seule |
| Sauvegarde Supabase distante | Terminé | Backup physique du 14 août 2026 à 03:25:44 UTC, restauration disponible |
| Sauvegarde Supabase Storage | Terminé | 22 médias archivés et vérifiés ; JSON cinéma exclu pour future table dédiée |
| Inventaire filesystem | Terminé | 1409 fichiers Dart recensés |
| Fondation Supabase existante | Audit initial terminé | `cours_scolarite`, quiz dynamiques et cycle éditorial repérés |
| Panneau existant | Audit initial terminé | Liste, Markdown, aperçu, publication et RPC sécurisées repérés |
| Classification structurelle fichier par fichier | Terminé | 1 409/1 409 fichiers lus et classifiés avec contenu, médias, dépendances et risque |
| Validation éditoriale et visuelle | À faire | À effectuer pendant l’extraction et la comparaison avec le rendu Flutter |
| Extraction complète | À faire | Convertir chaque page en blocs structurés sans perte |
| Import Supabase | À faire | Import idempotent avec preuve par fichier |
| Moteur Flutter universel | À faire | Chargement distant, cache et secours local |
| Création de cours dans le panneau | À faire | Filière, hiérarchie, route, blocs, médias et publication |
| Éditeur visuel par blocs | À faire | Deux modes synchronisés avec le Markdown |
| Supabase Storage | À faire | Upload, remplacement, aperçu et politiques |
| Quiz School et Exam | À faire | Import et administration de toutes les familles |
| Validation finale | À faire | Comparaison visuelle, tests, RLS, build statique |

## Plan de développement

### Phase 1 — Audit exhaustif

- [x] Générer le registre des fichiers.
- [x] Lire intégralement et classifier automatiquement chaque fichier.
- [ ] Associer chaque page à sa route dans `main.dart` et `app_router.dart`.
- [ ] Identifier les pages orphelines, doublons et redirections.
- [ ] Recenser tous les assets et composants spéciaux.
- [ ] Marquer les fichiers sans contenu éditorial comme `Non éditorial`.

### Phase 2 — Modèle Supabase

- [x] Auditer `cours_scolarite`, `quiz_scolarite_questions`, leurs politiques et leurs volumes.
- [x] Auditer globalement les tables publiques, la RLS, les fonctions privilégiées et Storage.
- [x] Certifier une sauvegarde physique restaurable de la base distante.
- [x] Sauvegarder séparément les médias Storage, hors JSON cinéma destiné à une table dédiée.
- [x] Ajouter uniquement les colonnes/tables manquantes.
- [x] Modéliser hiérarchie, blocs, versions, médias et liens quiz.
- [x] Créer les RPC administratives avec garde d’autorisation et audit.
- [x] Créer les politiques RLS de lecture publiée et d’administration.
- [ ] Tester les accès `anon`, `authenticated`, admin AAL2 et refus non-admin.

### Phase 3 — Extraction et import

- [x] Extraire titres, textes, RichText, listes, cartes, tableaux et références.
- [x] Conserver l’ordre exact des blocs extraits.
- [x] Associer routes, classes, catégories et modules.
- [x] Importer de façon idempotente dans Supabase.
- [x] Enregistrer dans le registre l’identifiant et la preuve Supabase.
- [ ] Comparer chaque contenu importé au fichier Dart source.

### Phase 4 — Application Flutter

- [x] Créer le chargement de contenu distant et son cache hors ligne.
- [ ] Créer le rendu des blocs correspondant aux designs existants.
- [x] Préserver toutes les routes actuelles.
- [x] Ajouter une route et un catalogue pour les nouveaux cours du panneau.
- [x] Ajouter un contenu en cache de secours hors ligne.
- [ ] Vérifier navigation, progression, journal et liens vers les quiz.

### Phase 5 — Panneau administrateur

- [x] Ajouter « Nouveau cours ».
- [x] Ajouter l’éditeur visuel par blocs existants.
- [x] Synchroniser éditeur visuel et Markdown.
- [ ] Ajouter glisser-déposer et réorganisation des blocs.
- [ ] Ajouter upload et bibliothèque Supabase Storage.
- [ ] Ajouter brouillon, aperçu, programmation, publication, archivage et versions.
- [ ] Étendre le panneau à tous les quiz PA/GPX School et Exam.

### Phase 6 — Vérification et livraison

- [ ] Tests unitaires et intégration Supabase.
- [ ] Analyse Flutter complète.
- [ ] Build Flutter concerné et build statique du panneau.
- [ ] Comparaison visuelle d’un échantillon puis de chaque famille de pages.
- [ ] Contrôle de complétude : 1 409/1 409 fichiers avec statut final.
- [ ] Générer `fae16dc1/admin` prêt à déposer.
- [ ] Créer la sauvegarde finale et son SHA-256.

## Journal de développement

### 2026-08-14T17:01:19.850765

- Périmètre fonctionnel confirmé avec le propriétaire.
- Sauvegarde complète créée et vérifiée.
- 1 409 fichiers Dart recensés dans PA/GPX Scolarité.
- Architecture existante du panneau, du moteur dynamique et du cycle éditorial identifiée.
- Registre exhaustif et document de progression générés.

### 2026-08-14 — Audit Supabase avant migration

- Projet distant `nuoonagnkhbeeymtvrcn` identifié actif et sain, offre Pro, région Paris.
- Audit SQL effectué en lecture seule : 202 tables publiques, toutes avec RLS activée, et 676 politiques.
- `cours_scolarite` contient 14 cours ; `quiz_scolarite_questions` contient 228 questions.
- Trois buckets publics observés, dont `assets`, sans politique Storage personnalisée.
- Conseillers Supabase analysés : 694 avis de sécurité et 276 avis de performance hérités.
- Rapport créé : [AUDIT_SUPABASE_AVANT_MIGRATION.md](./AUDIT_SUPABASE_AVANT_MIGRATION.md).
- La certification avait d'abord été bloquée par la reconnexion au tableau de bord ; elle a été finalisée dans l'entrée suivante.

### 2026-08-14 — Certification des sauvegardes

- Connexion au tableau de bord Supabase confirmée dans le panneau Codex.
- Backup physique quotidien du 14 août 2026 à 03:25:44 UTC vérifié comme restaurable.
- Copie complémentaire de 22 objets médias Storage créée dans `/private/tmp/copiq-supabase-storage-20260814.tar.gz`.
- Empreinte de l'archive Storage : `7e58a609348aa6151ff63c2ff84b5f4a51b0f7b1f417acfe383dc1d399dcd173`.
- `quiz_cinema_merged.jsonl` explicitement exclu ; sa copie locale a été supprimée et l'objet distant conservé pour traitement ultérieur.

### 2026-08-14 — Audit structurel exhaustif des fichiers de scolarité

- Les 1 409 fichiers Dart ont été ouverts et analysés intégralement par `tool/audit_scolarite_files.dart`.
- Contrôle conforme : 759 fichiers GPX, 650 fichiers PA et 1 409 chemins uniques.
- 1 928 024 lignes et 72 027 070 octets de code ont été analysés.
- Classification détectée : 1 142 cours/contenus, 177 quiz/QCM et 90 introductions.
- Chaque ligne contient la hiérarchie du cours, la route, la classe, le titre, les composants textuels, les médias, la navigation, les dépendances, Supabase et le risque de migration.
- Le document [AUDIT_DETAILLE_1409_FICHIERS_SCOLARITE.md](./AUDIT_DETAILLE_1409_FICHIERS_SCOLARITE.md) contient exactement 1 409 lignes de suivi.

### 2026-08-15 — Point de pause demandé par le propriétaire

- Développement volontairement mis en pause avant l’application de la migration vide `20260814233457_scolarite_imported_quiz_modules.sql`.
- Deux migrations additives ont été appliquées avec succès à Supabase : plateforme éditoriale et registre des sources. Aucune table existante n’a été supprimée.
- Registre Supabase vérifié : **1 409/1 409**, dont 759 GPX et 650 PA, 72 027 070 octets et 1 928 024 lignes.
- **1 232** cours/introductions sont présents dans `cours_scolarite` avec Markdown et blocs.
- **52 405** questions ont été extraites ; **48 755** questions uniques migrées sont présentes, réparties sur 176 fichiers contenant des questions. Le 177e fichier classé quiz ne contient aucune question normalisable.
- Les doublons internes exacts sont consolidés par la contrainte `(module, md5(question))`, sans perte de fichier dans le registre.
- Flutter : cache hors ligne, catalogue dynamique et résolution des routes de nouveaux cours ajoutés ; analyse ciblée sans erreur.
- Panneau : bouton de création et éditeur visuel/Markdown codés ; ESLint ciblé sans erreur.
- **Dernière opération non appliquée** : création locale du fichier vide `supabase/migrations/20260814233457_scolarite_imported_quiz_modules.sql`.
- **Reprise exacte** : remplir/appliquer cette migration pour créer les modules des quiz importés, puis terminer médias/versions, tests complets et build `fae16dc1/admin`.

## Règles de mise à jour du suivi

1. Mettre à jour le statut de chaque ligne du registre après chaque étape.
2. Ne marquer `Importé` qu’après retour positif de Supabase.
3. Ne marquer `Vérifié` qu’après comparaison avec le fichier source et contrôle du rendu.
4. Ajouter chaque changement important au journal ci-dessus.
5. Régénérer le registre après ajout, déplacement ou suppression autorisée d’un fichier Dart.
